// ANCHOR: here
struct User {
    active: bool,
    username: String,
    email: String,
    sign_in_count: u64,
}
// ANCHOR_END: here

fn main() {}
