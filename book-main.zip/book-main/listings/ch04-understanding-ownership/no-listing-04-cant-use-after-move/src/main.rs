fn main() {
    // ANCHOR: here
    let s1 = String::from("hello");
    let s2 = s1;

    println!("{s1}, world!");
    // ANCHOR_END: here
}
