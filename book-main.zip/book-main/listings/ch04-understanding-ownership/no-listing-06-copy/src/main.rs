fn main() {
    // ANCHOR: here
    let x = 5;
    let y = x;

    println!("x = {x}, y = {y}");
    // ANCHOR_END: here
}
