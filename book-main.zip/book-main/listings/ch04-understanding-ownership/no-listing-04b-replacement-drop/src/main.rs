fn main() {
    // ANCHOR: here
    let mut s = String::from("hello");
    s = String::from("ahoy");

    println!("{s}, world!");
    // ANCHOR_END: here
}
