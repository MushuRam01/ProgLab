fn main() {
    // ANCHOR: here
    let x: i8 = 5;
    let y: Option<i8> = Some(5);

    let sum = x + y;
    // ANCHOR_END: here
}
