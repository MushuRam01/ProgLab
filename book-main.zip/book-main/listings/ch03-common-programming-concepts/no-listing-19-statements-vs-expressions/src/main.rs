fn main() {
    let x = (let y = 6);
}
