fn main() {
    let number = 3;

    if number != 0 {
        println!("number was something other than zero");
    }
}
