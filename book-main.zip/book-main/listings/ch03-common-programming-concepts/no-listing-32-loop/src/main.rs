fn main() {
    loop {
        println!("again!");
    }
}
