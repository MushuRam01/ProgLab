fn main() {
    // ANCHOR: here
    let number = 7;
    // ANCHOR_END: here

    if number < 5 {
        println!("condition was true");
    } else {
        println!("condition was false");
    }
}
