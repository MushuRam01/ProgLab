## Macros

The 2018 edition of the book is no longer distributed with Rust's documentation.

If you came here via a link or web search, you may want to check out [the current
version of the book](../ch20-05-macros.html) instead.

If you have an internet connection, you can [find a copy distributed with
Rust
1.30](https://doc.rust-lang.org/1.30.0/book/2018-edition/ch19-06-macros.html).
